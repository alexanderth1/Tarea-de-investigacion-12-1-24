class alert{
    alertSugerencia(){
        Swal.fire({
            input: "textarea",
            inputLabel: "Message",
            inputPlaceholder: "Ingrese el mensaje de sugerencia...",
            inputAttributes: {
                "aria-label": "Type your message here"
            },
            showCancelButton: true
            });
            if (text) {
            Swal.fire(text);
        }
    }
    alertGuardado(){
        Swal.fire({
            position: "center",
            icon: "success",
            title: "Registrado con exito.",
            showConfirmButton: false,
            timer: 1500
        });
    }
    alertError(){
        Swal.fire({
            title: "Animal Incorrecto",
            text: "Esta no es la respuesta correcta",
            icon: "error",
            showConfirmButton: false,
            timer: 2000
          });
    }
    alertBien(){
        Swal.fire({
            title: "Animal Correcto",
            text: "Esta es la respuesta correcta",
            icon: "success",
            showConfirmButton: false,
            timer: 2000
          });
    }
}

let alertaimport = new alert()
