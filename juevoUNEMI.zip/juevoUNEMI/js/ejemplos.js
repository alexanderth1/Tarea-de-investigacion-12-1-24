/* !botones */

const slider = document.querySelector("#slider");
let sliderSection = document.querySelectorAll(".slider-frame");
let sliderSectionLast = sliderSection[sliderSection.length -1];

const btnLeft = document.querySelector("#btn-left");
const btnRigth = document.querySelector("#btn-right");

slider.insertAdjacentElement('afterbegin', sliderSectionLast);